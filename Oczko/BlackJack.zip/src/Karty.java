import java.util.HashMap;


public class Karty {
	protected HashMap<String, Integer> map = new HashMap<String, Integer>();
	
protected void shuffle()
{
	 map.put("Dwojka Kier",2);
	 map.put("Trojka Kier" ,3);
	 map.put("Czworka Kier",4);
	 map.put("Piatka Kier" ,5);
	 map.put("Szostka Kier",6);
	 map.put("Siodemka Kier",7);
	 map.put("Osemka Kier",8);	 
	 map.put("Dziewiatka Kier",9);
	 map.put("Dziesiatka Kier",10);
	 map.put("Walet Kier",10);
	 map.put("Dama Kier",10);
	 map.put("KrolKier",10);
	 map.put("AS Kier",11);
	 
	 
	 map.put("Dwojka Pik",2);
	 map.put("Trojka Pik" ,3);
	 map.put("Czworka Pik",4);
	 map.put("Piatka Pik" ,5);
	 map.put("Szostka Pik",6);
	 map.put("Siodemka Pik",7);
	 map.put("Osemka Pik",8);	 
	 map.put("Dziewiatka Pik",9);
	 map.put("Dziesiatka Pik",10);
	 map.put("Walet Pik",10);
	 map.put("Dama Pik",10);
	 map.put("Krol Pik",10);
	 map.put("AS Pik",11);
	 
	 
	 map.put("Dwojka Karo",2);
	 map.put("Trojka Karo" ,3);
	 map.put("Czworka Karo",4);
	 map.put("Piatka Karo" ,5);
	 map.put("Szostka Karo",6);
	 map.put("Siodemka Karo",7);
	 map.put("Osemka Karo",8);	 
	 map.put("Dziewiatka Karo",9);
	 map.put("Dziesiatka Karo",10);
	 map.put("Walet Karo",10);
	 map.put("Dama Karo",10);
	 map.put("Krol Karo",10);
	 map.put("AS Karo",11);
	 
	 
	 map.put("Dwojka Trefl",2);
	 map.put("Trojka Trefl" ,3);
	 map.put("Czworka Trefl",4);
	 map.put("Piatka Trefl" ,5);
	 map.put("Szostka Trefl",6);
	 map.put("Siodemka Trefl",7);
	 map.put("Osemka Trefl",8);	 
	 map.put("Dziewiatka Trefl",9);
	 map.put("Dziesiatka Trefl",10);
	 map.put("Walet Trefl",10);
	 map.put("Dama Trefl",10);
	 map.put("Krol Trefl",10);
	 map.put("AS Trefl",11);
}

	
}

	
